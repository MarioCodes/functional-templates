package es.codes.mario.commons.java.builders;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * This is my own class for building real-looking mocks & stubs. It allows me to give back a DTO or class, with almost-fully
 *  randomized variables. This spares me a lot of time for testing and Test-Driven-Development.
 *
 * How to use this class.
 *  1º. We want a stub for the entity 'Price' which holds all variables.
 *  2º. We create a 'PriceBuilder' class with the following header:
 *      public class PriceBuilder extends AbstractBuilder<PriceBuilder, Price>
 *  3º. Implement all abstract methods.
 *  4º. We may use it in a test as: PriceBuilder.getInstance().random().build();
 *      This will give you a class Price back with random variables inside to test.
 *
 * @param <BUILDER> -
 * @param <TYPE> -
 */
@Slf4j
@Getter
public abstract class AbstractBuilder<BUILDER, TYPE> extends Randomizer<TYPE> {

    private static final Integer DEFAULT_INSTANCES = 5;

    private final List<TYPE> instances;

    protected abstract TYPE instantiate();

    protected abstract BUILDER builder();

    protected AbstractBuilder() {
        this.instances = new ArrayList<>();
        this.prepareInstances();
    }

    private void prepareInstances() {
        for (int idx = 0; idx < DEFAULT_INSTANCES; idx++) {
            this.instances.add(this.instantiate());
        }
    }

    public TYPE build() {
        return this.instances.get(0);
    }

    public List<TYPE> buildList() {
        return this.instances;
    }

    public void with(final Consumer<TYPE> consumer) {
        this.instances.forEach(consumer);
    }

    public BUILDER random() {
        super.fill(this.instances);
        return this.builder();
    }

}
