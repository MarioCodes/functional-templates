package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.commons.java.builders.AbstractBuilder;
import es.codes.mario.prueba.software.bahia.dto.PriceRequest;

/**
 * Builder class to ease and improve my tests. For documentation please read {@link AbstractBuilder}.
 */
public class PriceRequestBuilder extends AbstractBuilder<PriceRequestBuilder, PriceRequest> {

    /*
     * Methods to copy, paste and modify in all *Builder instances.
     */

    public static PriceRequestBuilder getInstance() {
        return new PriceRequestBuilder();
    }

    @Override
    protected PriceRequest instantiate() {
        return new PriceRequest();
    }

    @Override
    protected PriceRequestBuilder builder() {
        return this;
    }

    /*
     * Custom 'with' methods per builder.
     */

}
