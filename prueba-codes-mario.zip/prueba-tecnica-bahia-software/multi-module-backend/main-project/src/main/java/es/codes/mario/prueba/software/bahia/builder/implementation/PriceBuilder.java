package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.commons.java.builders.AbstractBuilder;
import es.codes.mario.prueba.software.bahia.entity.Price;

/**
 * Builder class to ease and improve my tests. For documentation please read {@link AbstractBuilder}.
 */
public class PriceBuilder extends AbstractBuilder<PriceBuilder, Price> {

    /*
     * Methods to copy, paste and modify in all *Builder instances.
     */

    public static PriceBuilder getInstance() {
        return new PriceBuilder();
    }

    @Override
    protected Price instantiate() {
        return new Price();
    }

    @Override
    protected PriceBuilder builder() {
        return this;
    }

    /*
     * Custom 'with' methods per builder.
     */

    public PriceBuilder withBrandId(final Long id) {
        super.with(p -> p.setBrandId(id));
        return this;
    }
}
