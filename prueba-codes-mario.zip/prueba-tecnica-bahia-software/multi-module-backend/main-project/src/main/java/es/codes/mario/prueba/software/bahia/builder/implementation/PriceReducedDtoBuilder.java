package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.commons.java.builders.AbstractBuilder;
import es.codes.mario.prueba.software.bahia.dto.PriceReducedDto;

/**
 * Builder class to ease and improve my tests. For documentation please read {@link AbstractBuilder}.
 */
public class PriceReducedDtoBuilder extends AbstractBuilder<PriceReducedDtoBuilder, PriceReducedDto> {

    /*
     * Methods to copy, paste and modify in all *Builder instances.
     */

    public static PriceReducedDtoBuilder getInstance() {
        return new PriceReducedDtoBuilder();
    }

    @Override
    protected PriceReducedDto instantiate() {
        return new PriceReducedDto();
    }

    @Override
    protected PriceReducedDtoBuilder builder() {
        return this;
    }

    /*
     * Custom 'with' methods per builder.
     */

}
