package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.prueba.software.bahia.dto.PriceRequest;
import org.assertj.core.api.BDDAssertions;
import org.junit.Test;

import java.util.List;

public class PriceRequestBuilderTest {

    @Test
    public void testBuildOne() {
        // Given

        // When
        final PriceRequest price = PriceRequestBuilder.getInstance()
                .random()
                .build();

        // Then
        BDDAssertions.assertThat(price).isNotNull();
    }

    @Test
    public void testBuildList() {
        // Given

        // When
        final List<PriceRequest> price = PriceRequestBuilder.getInstance()
                .random()
                .buildList();

        // Then
        BDDAssertions.assertThat(price).isNotNull().hasSize(5);
    }


}