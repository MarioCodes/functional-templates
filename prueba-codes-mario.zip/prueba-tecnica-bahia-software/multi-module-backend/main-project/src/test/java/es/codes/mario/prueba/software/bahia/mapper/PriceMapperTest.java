package es.codes.mario.prueba.software.bahia.mapper;

import es.codes.mario.prueba.software.bahia.builder.implementation.PriceBuilder;
import es.codes.mario.prueba.software.bahia.dto.PriceReducedDto;
import es.codes.mario.prueba.software.bahia.entity.Price;
import org.assertj.core.api.BDDAssertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PriceMapperTest {

    @InjectMocks
    private PriceMapper mapper;

    @Test
    public void givenEntityWhenMapThenAllVariablesAreMapped() {
        // given
        final Price entity = PriceBuilder.getInstance()
                .random()
                .build();

        // when
        final PriceReducedDto dto = mapper.map(entity);

        // then
        BDDAssertions.assertThat(dto).isNotNull();
        BDDAssertions.assertThat(dto.getBrandId()).isEqualTo(entity.getBrandId());
        BDDAssertions.assertThat(dto.getStartDate()).isEqualTo(entity.getStartDate());
        BDDAssertions.assertThat(dto.getEndDate()).isEqualTo(entity.getEndDate());
        BDDAssertions.assertThat(dto.getPriceList()).isEqualTo(entity.getPriceList());
        BDDAssertions.assertThat(dto.getPrice()).isEqualTo(entity.getPrice());
        BDDAssertions.assertThat(dto.getCurrency()).isEqualTo(entity.getCurrency());
    }

}