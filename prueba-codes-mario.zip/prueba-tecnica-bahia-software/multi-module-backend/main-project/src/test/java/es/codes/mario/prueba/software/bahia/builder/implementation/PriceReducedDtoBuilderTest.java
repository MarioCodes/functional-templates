package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.prueba.software.bahia.dto.PriceReducedDto;
import org.assertj.core.api.BDDAssertions;
import org.junit.Test;

import java.util.List;

public class PriceReducedDtoBuilderTest {

    @Test
    public void testBuildOne() {
        // Given

        // When
        final PriceReducedDto price = PriceReducedDtoBuilder.getInstance()
                .random()
                .build();

        // Then
        BDDAssertions.assertThat(price).isNotNull();
    }

    @Test
    public void testBuildList() {
        // Given

        // When
        final List<PriceReducedDto> price = PriceReducedDtoBuilder.getInstance()
                .random()
                .buildList();

        // Then
        BDDAssertions.assertThat(price).isNotNull().hasSize(5);
    }

}