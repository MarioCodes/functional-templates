package es.codes.mario.prueba.software.bahia.builder.implementation;

import es.codes.mario.prueba.software.bahia.entity.Price;
import org.assertj.core.api.BDDAssertions;
import org.junit.Test;

import java.util.List;

public class PriceBuilderTest {

    @Test
    public void testBuildOne() {
        // Given

        // When
        final Price price = PriceBuilder.getInstance()
                .random()
                .withBrandId(10L)
                .build();

        // Then
        BDDAssertions.assertThat(price).isNotNull();
        BDDAssertions.assertThat(price.getBrandId()).isEqualTo(10L);
    }

    @Test
    public void testBuildList() {
        // Given

        // When
        final List<Price> price = PriceBuilder.getInstance()
                .random()
                .withBrandId(52L)
                .buildList();

        // Then
        BDDAssertions.assertThat(price).isNotNull().hasSize(5);
        BDDAssertions.assertThat(price).extracting("brandId")
                .hasSize(5)
                .containsOnly(52L);
    }

}