package es.codes.mario.prueba.software.bahia.service;

import com.googlecode.catchexception.apis.BDDCatchException;
import es.codes.mario.prueba.software.bahia.builder.implementation.PriceBuilder;
import es.codes.mario.prueba.software.bahia.builder.implementation.PriceReducedDtoBuilder;
import es.codes.mario.prueba.software.bahia.builder.implementation.PriceRequestBuilder;
import es.codes.mario.prueba.software.bahia.dao.PriceDao;
import es.codes.mario.prueba.software.bahia.dto.PriceReducedDto;
import es.codes.mario.prueba.software.bahia.dto.PriceRequest;
import es.codes.mario.prueba.software.bahia.entity.Price;
import es.codes.mario.prueba.software.bahia.exception.EntityNotFoundException;
import es.codes.mario.prueba.software.bahia.mapper.PriceMapper;
import org.assertj.core.api.BDDAssertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class PriceServiceTest {

    @Mock
    private PriceDao daoMock;

    @Mock
    private PriceMapper mapperMock;

    @InjectMocks
    private PriceService service;

    @Test
    public void givenPriceRequestNotFoundWhenRetrievePriceThenCorrectExceptionThrown() {
        // given
        final PriceRequest request = PriceRequestBuilder.getInstance()
                .random()
                .build();

        final Optional<Price> optPrice = Optional.empty();
        BDDMockito.given(daoMock.findOneByLocalDateTimeAndProductIdAndBrandId(request.getApplicationDate(),
                request.getProductId(), request.getBrandId())).willReturn(optPrice);

        // when
        BDDCatchException.when(service).retrievePrice(request);

        // then
        BDDAssertions.assertThat(BDDCatchException.caughtException())
                .isInstanceOf(EntityNotFoundException.class)
                .hasMessage("The entity with the following data could not be found. " +
                        " Date: " + request.getApplicationDate() + ", productId: " + request.getProductId() + ", brandId: " + request.getBrandId());
    }

    @Test
    public void givenPriceRequestWhenRetrievePriceThenCorrectlyMapped() {
        // given
        final PriceRequest request = PriceRequestBuilder.getInstance()
                .random()
                .build();

        final Price price = PriceBuilder.getInstance()
                .random()
                .build();
        final Optional<Price> optPrice = Optional.of(price);
        BDDMockito.given(daoMock.findOneByLocalDateTimeAndProductIdAndBrandId(request.getApplicationDate(),
                request.getProductId(), request.getBrandId())).willReturn(optPrice);

        final PriceReducedDto dto = PriceReducedDtoBuilder.getInstance()
                .random()
                .build();
        BDDMockito.given(this.mapperMock.map(price))
                .willReturn(dto);

        // when
        final PriceReducedDto response = service.retrievePrice(request);

        // then
        BDDAssertions.assertThat(response).isNotNull()
                .isSameAs(dto);
    }

}